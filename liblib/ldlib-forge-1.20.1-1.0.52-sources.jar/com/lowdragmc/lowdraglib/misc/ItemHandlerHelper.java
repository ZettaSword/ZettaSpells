package com.lowdragmc.lowdraglib.misc;

import net.minecraft.world.item.ItemStack;

/**
 * @author KilaBash
 * @date 2023/3/13
 * @implNote ItemHandlerHelper
 */
public class ItemHandlerHelper {
    public static boolean canItemStacksStack(ItemStack first, ItemStack second) {
        if (!first.m_41619_() && ItemStack.m_41656_(first, second) && first.m_41782_() == second.m_41782_()) {
            return !first.m_41782_() || first.m_41783_().equals(second.m_41783_());
        } else {
            return false;
        }
    }

    public static ItemStack copyStackWithSize(ItemStack stack, int size) {
        if (size == 0) {
            return ItemStack.f_41583_;
        } else {
            ItemStack copy = stack.m_41777_();
            copy.m_41764_(size);
            return copy;
        }
    }
}
