package com.lowdragmc.lowdraglib.syncdata.payload;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.Tag;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.world.item.ItemStack;

public class ItemStackPayload extends ObjectTypedPayload<ItemStack> {

    @Override
    public void writePayload(FriendlyByteBuf buf) {
        buf.m_130055_(payload);
    }

    @Override
    public void readPayload(FriendlyByteBuf buf) {
        payload = buf.m_130267_();
    }

    @Override
    public Tag serializeNBT() {
        return payload.m_41739_(new CompoundTag());
    }

    @Override
    public void deserializeNBT(Tag tag) {
        payload = ItemStack.m_41712_((CompoundTag) tag);
    }

    @Override
    public Object copyForManaged(Object value) {
        if (value instanceof ItemStack) {
            return ((ItemStack) value).m_41777_();
        }
        return super.copyForManaged(value);
    }
}

