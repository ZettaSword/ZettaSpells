package com.lowdragmc.lowdraglib.syncdata.payload;

import net.minecraft.nbt.StringTag;
import net.minecraft.nbt.Tag;
import net.minecraft.network.FriendlyByteBuf;

public class StringPayload extends ObjectTypedPayload<String> {

    @Override
    public void writePayload(FriendlyByteBuf buf) {
        buf.m_130070_(payload);
    }

    @Override
    public void readPayload(FriendlyByteBuf buf) {
        payload = buf.m_130277_();
    }

    @Override
    public Tag serializeNBT() {
        return StringTag.m_129297_(payload);
    }

    @Override
    public void deserializeNBT(Tag tag) {
        payload = tag.m_7916_();
    }

    public static StringPayload of(String value) {
        var payload = new StringPayload();
        payload.setPayload(value);
        return payload;
    }
}
