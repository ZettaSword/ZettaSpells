package com.lowdragmc.lowdraglib.syncdata.accessor;

import com.lowdragmc.lowdraglib.syncdata.AccessorOp;
import com.lowdragmc.lowdraglib.syncdata.payload.ITypedPayload;
import com.lowdragmc.lowdraglib.syncdata.payload.NbtTagPayload;
import net.minecraft.nbt.CompoundTag;
import org.joml.Quaternionf;

public class QuaternionfAccessor extends CustomObjectAccessor<Quaternionf>{

    public QuaternionfAccessor() {
        super(Quaternionf.class, true);
    }

    @Override
    public ITypedPayload<?> serialize(AccessorOp op, Quaternionf value) {
        CompoundTag tag = new CompoundTag();
        tag.m_128350_("x", value.x);
        tag.m_128350_("y", value.y);
        tag.m_128350_("z", value.z);
        tag.m_128350_("w", value.w);
        return NbtTagPayload.of(tag);
    }

    @Override
    public Quaternionf deserialize(AccessorOp op, ITypedPayload<?> payload) {
        if (payload instanceof NbtTagPayload nbtTagPayload) {
            var tag = (CompoundTag)nbtTagPayload.getPayload();
            return new Quaternionf(tag.m_128457_("x"), tag.m_128457_("y"), tag.m_128457_("z"), tag.m_128457_("w"));
        }
        return null;
    }
}
