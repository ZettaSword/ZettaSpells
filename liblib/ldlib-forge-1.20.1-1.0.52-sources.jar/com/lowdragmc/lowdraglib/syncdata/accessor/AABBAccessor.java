package com.lowdragmc.lowdraglib.syncdata.accessor;

import com.lowdragmc.lowdraglib.syncdata.AccessorOp;
import com.lowdragmc.lowdraglib.syncdata.payload.ITypedPayload;
import com.lowdragmc.lowdraglib.syncdata.payload.NbtTagPayload;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.phys.AABB;

public class AABBAccessor extends CustomObjectAccessor<AABB>{

    public AABBAccessor() {
        super(AABB.class, true);
    }

    @Override
    public ITypedPayload<?> serialize(AccessorOp op, AABB value) {
        CompoundTag tag = new CompoundTag();
        tag.m_128347_("minX", value.f_82288_);
        tag.m_128347_("minY", value.f_82289_);
        tag.m_128347_("minZ", value.f_82290_);
        tag.m_128347_("maxX", value.f_82291_);
        tag.m_128347_("maxY", value.f_82292_);
        tag.m_128347_("maxZ", value.f_82293_);
        return NbtTagPayload.of(tag);
    }

    @Override
    public AABB deserialize(AccessorOp op, ITypedPayload<?> payload) {
        if (payload instanceof NbtTagPayload nbtTagPayload && nbtTagPayload.getPayload() instanceof CompoundTag tag) {
            return new AABB(
                    tag.m_128459_("minX"),
                    tag.m_128459_("minY"),
                    tag.m_128459_("minZ"),
                    tag.m_128459_("maxX"),
                    tag.m_128459_("maxY"),
                    tag.m_128459_("maxZ")
            );
        }
        return null;
    }
}
