package com.lowdragmc.lowdraglib.gui.editor.ui.sceneeditor.sceneobject.utils;

import com.lowdragmc.lowdraglib.gui.editor.ui.sceneeditor.sceneobject.ISceneRendering;
import com.lowdragmc.lowdraglib.gui.editor.ui.sceneeditor.sceneobject.SceneObject;
import com.mojang.blaze3d.vertex.PoseStack;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.block.BlockRenderDispatcher;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;

public class BlockModelObject extends SceneObject implements ISceneRendering {
    public BlockState blockState = Blocks.f_50069_.m_49966_();

    public BlockModelObject() {
    }

    @Override
    @Environment(EnvType.CLIENT)
    public void drawInternal(PoseStack poseStack, MultiBufferSource bufferSource, float partialTicks) {
        var renderer = Minecraft.m_91087_().m_91289_();
        poseStack.m_85837_(-0.5, -0.5, -0.5);
        renderer.m_110912_(blockState, poseStack, bufferSource, 0xf000f0, OverlayTexture.f_118083_);
    }
}
