package com.lowdragmc.lowdraglib.utils.virtual;

import com.lowdragmc.lowdraglib.utils.DummyWorld;
import it.unimi.dsi.fastutil.longs.LongSet;
import it.unimi.dsi.fastutil.longs.LongSets;
import it.unimi.dsi.fastutil.shorts.ShortList;
import net.minecraft.MethodsReturnNonnullByDefault;
import net.minecraft.Util;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.chunk.*;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.levelgen.structure.Structure;
import net.minecraft.world.level.levelgen.structure.StructureStart;
import net.minecraft.world.level.material.Fluid;
import net.minecraft.world.level.material.FluidState;
import net.minecraft.world.level.material.Fluids;
import net.minecraft.world.ticks.BlackholeTickAccess;
import net.minecraft.world.ticks.LevelChunkTicks;
import net.minecraft.world.ticks.TickContainerAccess;

import javax.annotation.Nullable;
import javax.annotation.ParametersAreNonnullByDefault;
import java.util.Collection;
import java.util.Collections;
import java.util.Map;
import java.util.Set;

@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
public class VirtualChunk extends LevelChunk {
	boolean needsLight;
	final int x;
	final int z;

	public VirtualChunk(DummyWorld world, int x, int z) {
		super(
            world,
            new ChunkPos(x, z),
            UpgradeData.f_63320_,
            new LevelChunkTicks<>(),
            new LevelChunkTicks<>(),
            0L,
            Util.m_137469_(new LevelChunkSection[world.m_151559_()], sections -> {
                for (int i = 0; i < sections.length; i++) {
                    sections[i] = new VirtualChunkSection(world, new ChunkPos(x, z), i << 4);
                }
            }),
            null,
            null
            );

		this.needsLight = true;
		this.x = x;
		this.z = z;
	}

	public DummyWorld getDummyWorld() {
		return (DummyWorld) this.m_62953_();
	}

    @Override
	public ChunkStatus m_6415_() {
		return ChunkStatus.f_62323_;
	}

	@Nullable
	@Override
	public BlockState m_6978_(BlockPos p_177436_1_, BlockState p_177436_2_, boolean p_177436_3_) {
		return null;
	}

	@Override
	public void m_142169_(BlockEntity p_177426_2_) {}

	@Override
	public void m_6286_(Entity p_76612_1_) {}

	@Override
	public Set<BlockPos> m_5928_() {
		return Set.of();
	}

	@Override
	public Collection<Map.Entry<Heightmap.Types, Heightmap>> m_6890_() {
		return Collections.emptyList();
	}

	@Override
	public void m_6511_(Heightmap.Types p_201607_1_, long[] p_201607_2_) {}

	@Override
	public Heightmap m_6005_(Heightmap.Types p_217303_1_) {
		return null;
	}

	@Override
	public void m_8092_(boolean p_177427_1_) {}

	@Override
	public boolean m_6344_() {
		return false;
	}

	@Override
	public void m_8114_(BlockPos pos) {
		getDummyWorld().m_46747_(pos);
	}

	@Override
	public ShortList[] m_6720_() {
		return new ShortList[0];
	}

	@Nullable
	@Override
	public CompoundTag m_8049_(BlockPos p_201579_1_) {
		return null;
	}

	@Nullable
	@Override
	public CompoundTag m_8051_(BlockPos p_223134_1_) {
		return null;
	}

	@Override
	public UpgradeData m_7387_() {
		return null;
	}

	@Override
	public void m_6141_(long p_177415_1_) {}

	@Override
	public long m_6319_() {
		return 0;
	}

	@Override
	public boolean m_6332_() {
		return needsLight;
	}

	@Override
	public void m_8094_(boolean needsLight) {
		this.needsLight = needsLight;
	}

	@Nullable
	@Override
	public BlockEntity m_7702_(BlockPos pos) {
		return getDummyWorld().m_7702_(pos);
	}

	@Override
	public BlockState m_8055_(BlockPos pos) {
		return getDummyWorld().m_8055_(pos);
	}

	@Override
	public FluidState m_6425_(BlockPos p_204610_1_) {
		return Fluids.f_76191_.m_76145_();
	}

	@Override
	@Nullable
	public StructureStart m_213652_(Structure structure) {
		return null;
	}

	@Override
	public void m_213792_(Structure structure, StructureStart start) {
	}

	@Override
	public Map<Structure, StructureStart> m_6633_() {
		return Collections.emptyMap();
	}

	@Override
	public void m_8040_(Map<Structure, StructureStart> structureStarts) {
	}

	@Override
	public LongSet m_213649_(Structure structure) {
		return LongSets.emptySet();
	}

	@Override
	public void m_213843_(Structure structure, long reference) {
	}

	@Override
	public Map<Structure, LongSet> m_62769_() {
		return Collections.emptyMap();
	}

	@Override
	public void m_62737_(Map<Structure, LongSet> structureReferences) {
	}

	@Override
	public TickContainerAccess<Fluid> m_183526_() {
		return BlackholeTickAccess.m_193144_();
	}

	@Override
	public TicksToSave m_183568_() {
		return null;
	}

	@Override
	public TickContainerAccess<Block> m_183531_() {
		return BlackholeTickAccess.m_193144_();
	}

}
