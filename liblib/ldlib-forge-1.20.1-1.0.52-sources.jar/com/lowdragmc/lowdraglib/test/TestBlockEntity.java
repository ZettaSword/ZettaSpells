package com.lowdragmc.lowdraglib.test;

import com.lowdragmc.lowdraglib.LDLib;
import com.lowdragmc.lowdraglib.gui.compass.CompassView;
import com.lowdragmc.lowdraglib.gui.factory.BlockEntityUIFactory;
import com.lowdragmc.lowdraglib.gui.modular.IUIHolder;
import com.lowdragmc.lowdraglib.gui.modular.ModularUI;
import com.lowdragmc.lowdraglib.gui.widget.SceneWidget;
import com.lowdragmc.lowdraglib.syncdata.IManaged;
import com.lowdragmc.lowdraglib.syncdata.IManagedStorage;
import com.lowdragmc.lowdraglib.syncdata.annotation.DescSynced;
import com.lowdragmc.lowdraglib.syncdata.annotation.Persisted;
import com.lowdragmc.lowdraglib.syncdata.annotation.ReadOnlyManaged;
import com.lowdragmc.lowdraglib.syncdata.blockentity.IAsyncAutoSyncBlockEntity;
import com.lowdragmc.lowdraglib.syncdata.field.FieldManagedStorage;
import com.lowdragmc.lowdraglib.syncdata.field.ManagedFieldHolder;
import com.lowdragmc.lowdraglib.syncdata.managed.IRef;
import com.lowdragmc.lowdraglib.test.sync.TestReadOnlyManaged;
import dev.architectury.injectables.annotations.ExpectPlatform;
import lombok.Getter;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;

import java.util.HashSet;
import java.util.Set;

/**
 * @author KilaBash
 * @date 2022/05/24
 * @implNote TODO
 */
public class TestBlockEntity extends BlockEntity implements IUIHolder.BlockEntityUI, IAsyncAutoSyncBlockEntity, IManaged {

    protected static final ManagedFieldHolder MANAGED_FIELD_HOLDER = new ManagedFieldHolder(TestBlockEntity.class);
    @Getter
    private final FieldManagedStorage syncStorage = new FieldManagedStorage(this);

    @DescSynced
    @Persisted
    @ReadOnlyManaged(onDirtyMethod = "onDirty",
            serializeMethod = "serializeUid",
            deserializeMethod = "deserializeUid")
    public TestReadOnlyManaged testReadOnlyManaged = new TestReadOnlyManaged(this);

    public TestBlockEntity(BlockPos pWorldPosition, BlockState pBlockState) {
        super(TYPE(), pWorldPosition, pBlockState);
    }

    @ExpectPlatform
    public static BlockEntityType<?> TYPE() {
        throw new AssertionError();
    }

    public void use(Player player) {
        if (!m_58904_().f_46443_) {
            BlockEntityUIFactory.INSTANCE.openUI(this, (ServerPlayer) player);
        }
    }

    @Override
    public ModularUI createUI(Player entityPlayer) {
        Set<BlockPos> positions = new HashSet<>();
        positions.add(this.f_58858_);

        BlockPos.MutableBlockPos mutable = this.f_58858_.m_122032_();
        for (Direction dir : Direction.values()) {
            for (Direction dir2 : Direction.values()) {
                if (dir == dir2 || dir == dir2.m_122424_()) continue;
                positions.add(mutable.m_122159_(this.f_58858_, dir).m_122173_(dir2).m_7949_());
            }
        };

        return new ModularUI(this, entityPlayer)
                .widget(new CompassView(LDLib.MOD_ID))
                .widget(new SceneWidget(64, 64, 300, 300, entityPlayer.m_9236_(), true)
                        .setRenderedCore(positions)
                        .useOrtho(false));
//        return new ModularUI(this, entityPlayer).widget(new UIEditor(LDLib.location));
    }

    @Override
    public IManagedStorage getRootStorage() {
        return getSyncStorage();
    }

    @Override
    public ManagedFieldHolder getFieldHolder() {
        return MANAGED_FIELD_HOLDER;
    }

    @Override
    public void onChanged() {
        markAsDirty();
    }

    @SuppressWarnings("unused")
    private boolean onDirty(TestReadOnlyManaged testManaged) {
        if (testManaged != null) {
            for (IRef ref : testManaged.getSyncStorage().getNonLazyFields()) {
                ref.update();
            }
            return testManaged.getSyncStorage().hasDirtySyncFields() ||
                    testManaged.getSyncStorage().hasDirtyPersistedFields();
        }
        return false;
    }

    @SuppressWarnings("unused")
    private CompoundTag serializeUid(TestReadOnlyManaged coverBehavior) {
        var uid = new CompoundTag();
        uid.m_128359_("id", "testID");
        return uid;
    }

    @SuppressWarnings("unused")
    private TestReadOnlyManaged deserializeUid(CompoundTag uid) {
        return new TestReadOnlyManaged(this);
    }
}
