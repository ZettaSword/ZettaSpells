package com.lowdragmc.lowdraglib.test;

import net.minecraft.core.Direction;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;

/**
 * @author KilaBash
 * @date 2022/05/24
 * @implNote TestBlock
 */
public class NoRendererTestBlock extends Block {

    public static final NoRendererTestBlock BLOCK = new NoRendererTestBlock();
    private NoRendererTestBlock() {
        super(Properties.m_284310_().m_60955_().m_155954_(5));
        this.m_49959_(this.m_49966_().m_61124_(BlockStateProperties.f_61372_, Direction.NORTH));
    }

    @Override
    protected void m_7926_(StateDefinition.Builder<Block, BlockState> pBuilder) {
        pBuilder.m_61104_(BlockStateProperties.f_61372_);
    }

    public BlockState m_5573_(BlockPlaceContext context) {
        return this.m_49966_().m_61124_(BlockStateProperties.f_61372_, context.m_7820_());
    }
}
