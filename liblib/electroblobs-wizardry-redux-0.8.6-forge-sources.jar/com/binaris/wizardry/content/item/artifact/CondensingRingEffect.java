package com.binaris.wizardry.content.item.artifact;

import com.binaris.wizardry.api.content.item.IManaItem;
import com.binaris.wizardry.api.content.util.EntityUtil;
import com.binaris.wizardry.core.ArtifactEffectContext;
import com.binaris.wizardry.core.IArtifactEffect;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;

public class CondensingRingEffect implements IArtifactEffect {
    public static final int MANA_RECHARGE_INTERVAL_TICKS = 150;

    @Override
    public void onTick(LivingEntity user, Level level, ArtifactEffectContext context) {
        if (user instanceof Player player && player.tickCount % MANA_RECHARGE_INTERVAL_TICKS == 0) {
            EntityUtil.getHotbarItems(player).stream()
                    .filter(st -> st.getItem() instanceof IManaItem)
                    .forEach(st -> ((IManaItem) st.getItem()).rechargeMana(st, 1));
        }
    }
}
