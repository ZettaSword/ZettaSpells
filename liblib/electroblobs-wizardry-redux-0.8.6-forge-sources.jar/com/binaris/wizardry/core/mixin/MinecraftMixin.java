package com.binaris.wizardry.core.mixin;

import com.binaris.wizardry.api.content.event.EBClientTickEvent;
import com.binaris.wizardry.core.event.WizardryEventBus;
import net.minecraft.client.Minecraft;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Minecraft.class)
public abstract class MinecraftMixin {
    @Inject(method = "tick", at = @At("TAIL"))
    public void EBWIZARDRY$clientTick(CallbackInfo ci) {
        Minecraft minecraft = ((Minecraft) (Object) this);
        WizardryEventBus.fireEvent(new EBClientTickEvent(minecraft));
    }
}
