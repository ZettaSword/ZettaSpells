package com.binaris.wizardry.api.content.entity.projectile;


import com.binaris.wizardry.api.content.util.MagicDamageSource;
import com.binaris.wizardry.api.content.util.RayTracer;
import com.binaris.wizardry.content.spell.abstr.ArrowSpell;
import com.binaris.wizardry.core.AllyDesignation;
import com.binaris.wizardry.core.integrations.ArtifactChannel;
import com.binaris.wizardry.setup.registries.EBItems;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.resources.ResourceKey;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.util.Mth;
import net.minecraft.world.damagesource.DamageType;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.AbstractArrow;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.enchantment.EnchantmentHelper;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import org.jetbrains.annotations.NotNull;

/// This class uses the base code from [AbstractArrow] and adds some methods to make it easier to use with the mod.
/// This is used as a base class for all the magic arrows spelled by the [ArrowSpell] class.
///
/// The methods [#aim(LivingEntity, float)] and [#aim(LivingEntity, Entity, float, float)] are used to set
/// the shooter of the projectile and aim it in the direction they are looking. (Originally copied from Ebwizardry 1.12.2)
public abstract class MagicArrowEntity extends AbstractArrow {
    public static final double LAUNCH_Y_OFFSET = 0.3;
    public static final float FORWARD_OFFSET = 0.1f;
    public static final int SEEKING_TIME = 15;
    public float damageMultiplier = 1.0f;
    protected int ticksInGround;
    protected int ticksInAir;

    public MagicArrowEntity(EntityType<? extends AbstractArrow> entityType, Level world) {
        super(entityType, world);
    }

    /// Returns the damage dealt by this arrow. Keep in mind that the damage multiplier is applied after this value.
    ///
    /// @return The base damage dealt by this arrow.
    public abstract double getDamage(@NotNull EntityHitResult hitResult);

    /// Returns the maximum flight time in ticks before this projectile disappears, or -1 if it can continue indefinitely
    /// until it hits something. This should be constant.
    ///
    /// @return The maximum flight time in ticks.
    public abstract int getLifetime();

    /// This method is used to get the damage type of the magic arrow. You must override this and return a valid
    /// `ResourceKey<DamageType>` for your magic arrow's damage type.
    ///
    /// @return The damage type of the magic arrow.
    public abstract ResourceKey<DamageType> getDamageType(@NotNull EntityHitResult hitResult);

    /// Disable/enable deceleration (generally speaking, this isn't noticeable unless gravity is turned off). Making the arrow
    /// not decelerate will make it move at a constant speed.
    ///
    /// @return True if the arrow should decelerate, false otherwise.
    public boolean doDeceleration() {
        return true;
    }

    /// Allow the projectile to pass through mobs intact (the onEntityHit method will still be called
    /// and damage will still be applied).
    ///
    /// @return True if the arrow should pass through mobs, false otherwise.
    public boolean doOverpenetration() {
        return false;
    }

    /// **This isn't for applying damage to the entity**
    ///
    /// Here you can apply any extra effects to the entity that was hit by the projectile. (e.g. setting fire, poisoning, etc.)
    ///
    /// @param hitResult The result of the hit.
    public void onHitTargetExtraEffects(@NotNull EntityHitResult hitResult) {
    }

    /// Returns true if the entity is a valid target for the arrow, by default this is handled by the ally system.
    ///
    /// @param entity The entity to check.
    public boolean isValidTarget(@NotNull Entity entity) {
        Entity owner = this.getOwner() != null ? this.getOwner() : this;
        return AllyDesignation.isValidTarget(owner, entity);
    }

    /// Returns the sound event of the arrow.
    ///
    /// @param result The result of the hit.
    public @NotNull SoundEvent getSoundEvent(HitResult result) {
        return SoundEvents.EMPTY;
    }

    /// Plays the sound of the arrow.
    ///
    /// @param result The result of the hit.
    protected void playHitSound(HitResult result) {
        this.playSound(this.getSoundEvent(result), 1.0F, 1.2F / (this.random.nextFloat() * 0.2F + 0.9F));
    }

    /// Returns the seeking strength of this arrow, or the maximum distance from a target the projectile can be
    /// heading for that will make it curve towards that target.
    ///
    /// @return The seeking strength of the magic arrow.
    public float getSeekingStrength() {
        return getOwner() instanceof Player player && ArtifactChannel.isEquipped(player, EBItems.RING_SEEKING.get()) ? 2 : 0;
    }

    /// Ticks when the arrow is in the ground
    public void tickInGround() {
    }

    /// Ticks when the arrow is in the air
    public void ticksInAir() {
    }


    @Override
    public void tick() {
        super.tick();

        if (getLifetime() >= 0 && this.tickCount >= getLifetime()) {
            this.discard();
        }

        if (inGround) {
            ticksInGround++;
            tickInGround();
        } else {
            ticksInAir++;
            ticksInAir();
        }

//        if (doDeceleration() && tickCount % 10 == 0) {
//            this.setDeltaMovement(this.getDeltaMovement().scale(0.90));
//        }

        if (getSeekingStrength() <= 0) return;
        HitResult hit = RayTracer.rayTrace(level(), this, this.position(), this.position().add(this.getDeltaMovement().scale(SEEKING_TIME)), getSeekingStrength(), false, LivingEntity.class, RayTracer.ignoreEntityFilter(null));

        if (hit instanceof EntityHitResult entityHit && getOwner() instanceof LivingEntity owner && entityHit.getEntity() instanceof LivingEntity entity) {
            if (AllyDesignation.isValidTarget(owner, entity)) {
                Vec3 direction = new Vec3(entity.xo, entity.yo + entity.getDimensions(entity.getPose()).height / 2, entity.zo).subtract(this.position()).normalize().scale(this.getDeltaMovement().length());
                this.setDeltaMovement(this.getDeltaMovement().add(direction.subtract(this.getDeltaMovement()).scale(2.0 / SEEKING_TIME)));
            }
        }
    }


    /// Sets the shooter of the projectile to the given caster, positions the projectile at the given caster's eyes and
    /// aims it in the direction they are looking with the given speed.
    public void aim(LivingEntity caster, float speed) {
        if (getOwner() == null) this.setOwner(caster);

        Vec3 lookVector = caster.getLookAngle();

        this.absMoveTo(
                caster.xo + lookVector.x * FORWARD_OFFSET,
                caster.getY() + caster.getDimensions(caster.getPose()).height - LAUNCH_Y_OFFSET,
                caster.zo + lookVector.z * FORWARD_OFFSET
                , caster.getYRot(), caster.getXRot());

        this.xo -= Mth.cos(this.getYRot() / 180.0F * (float) Math.PI) * 0.16F;
        this.yo -= 0.10000000149011612D;
        this.zo -= Mth.cos(this.getYRot() / 180.0F * (float) Math.PI) * 0.16F;

        this.setPos(xo, yo, zo);

        double motionX = -Mth.sin(this.getYRot() / 180.0F * (float) Math.PI)
                * Mth.cos(this.getXRot() / 180.0F * (float) Math.PI);
        double motionY = -Mth.sin(this.getXRot() / 180.0F * (float) Math.PI);
        double motionZ = Mth.cos(this.getYRot() / 180.0F * (float) Math.PI)
                * Mth.cos(this.getXRot() / 180.0F * (float) Math.PI);

        this.shoot(motionX, motionY, motionZ, speed * 1.5F, 1.0F);

    }

    public void aim(LivingEntity caster, Entity target, float speed, float aimingError) {
        if (getOwner() == null) this.setOwner(caster);

        this.yo = caster.yo + (double) caster.getDimensions(caster.getPose()).height * 0.85F - LAUNCH_Y_OFFSET;
        double dx = target.xo - caster.xo;
        double dy = !this.isNoGravity() ?
                target.yo + (double) (target.getDimensions(caster.getPose()).height / 3.0f) - this.yo
                : target.yo + (double) (target.getDimensions(caster.getPose()).height / 2.0f) - this.yo;
        double dz = target.zo - caster.zo;
        double horizontalDistance = Mth.sqrt((float) (dx * dx + dz * dz));

        if (horizontalDistance >= 1.0E-7D) {
            float yaw = (float) (Math.atan2(dz, dx) * 180.0d / Math.PI) - 90.0f;
            float pitch = (float) (-(Math.atan2(dy, horizontalDistance) * 180.0d / Math.PI));
            double dxNormalised = dx / horizontalDistance;
            double dzNormalised = dz / horizontalDistance;
            this.absMoveTo(caster.xo + dxNormalised, this.yo, caster.zo + dzNormalised, yaw, pitch);

            float bulletDropCompensation = !this.isNoGravity() ? (float) horizontalDistance * 0.2f : 0;
            this.shoot(dx, dy + (double) bulletDropCompensation, dz, speed, aimingError);
        }
    }

    @Override
    protected void onHitEntity(@NotNull EntityHitResult hitResult) {
        if (!(hitResult.getEntity() instanceof LivingEntity target)) return;
        if (!isValidTarget(target)) return;

        MagicDamageSource.causeMagicDamage(this, target, (float) getDamage(hitResult) * damageMultiplier, this.getDamageType(hitResult));
        this.onHitTargetExtraEffects(hitResult);
        this.playHitSound(hitResult);

        // Knockback and post effects
        if (this.getKnockback() > 0) {
            double knockback = Math.max(0.0, 1.0 - target.getAttributeValue(Attributes.KNOCKBACK_RESISTANCE));
            Vec3 vecKnockback = this.getDeltaMovement().multiply(1.0, 0.0, 1.0).normalize().scale((double) this.getKnockback() * 0.6 * knockback);
            if (vecKnockback.lengthSqr() > 0.0) {
                target.push(vecKnockback.x, 0.1, vecKnockback.z);
            }
        }

        if (!this.level().isClientSide && getOwner() instanceof LivingEntity arrowOwner) {
            EnchantmentHelper.doPostHurtEffects(target, arrowOwner);
            EnchantmentHelper.doPostDamageEffects(arrowOwner, target);
        }

        if (!this.level().isClientSide) {
            if (!this.doOverpenetration()) this.discard();
        }
    }

    @Override
    protected void onHitBlock(@NotNull BlockHitResult result) {
        super.onHitBlock(result);
        this.playHitSound(result);
    }

    @Override
    public void addAdditionalSaveData(@NotNull CompoundTag compound) {
        super.addAdditionalSaveData(compound);
        compound.putInt("ticksInAir", ticksInAir);
        compound.putInt("ticksInGround", ticksInGround);
        compound.putFloat("damageMultiplier", damageMultiplier);
    }

    @Override
    public void readAdditionalSaveData(@NotNull CompoundTag compound) {
        super.readAdditionalSaveData(compound);
        ticksInAir = compound.getInt("ticksInAir");
        ticksInGround = compound.getInt("ticksInGround");
        damageMultiplier = compound.getFloat("damageMultiplier");
    }

    @Override
    protected boolean tryPickup(@NotNull Player player) {
        return false;
    }

    @Override
    protected @NotNull SoundEvent getDefaultHitGroundSoundEvent() {
        return SoundEvents.EMPTY;
    }

    @Override
    protected @NotNull ItemStack getPickupItem() {
        return ItemStack.EMPTY;
    }
}
