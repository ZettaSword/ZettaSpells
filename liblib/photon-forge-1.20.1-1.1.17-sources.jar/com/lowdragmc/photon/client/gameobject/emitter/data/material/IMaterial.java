package com.lowdragmc.photon.client.gameobject.emitter.data.material;

import com.lowdragmc.lowdraglib.gui.editor.configurator.IConfigurable;
import com.lowdragmc.lowdraglib.gui.texture.IGuiTexture;
import com.lowdragmc.lowdraglib.syncdata.ITagSerializable;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.nbt.CompoundTag;

import javax.annotation.ParametersAreNonnullByDefault;
import java.util.ArrayList;
import java.util.List;

/**
 * @author KilaBash
 * @date 2023/5/29
 * @implNote Material
 */
@Environment(EnvType.CLIENT)
@ParametersAreNonnullByDefault
public interface IMaterial extends IConfigurable, ITagSerializable<CompoundTag> {

    List<Class<? extends IMaterial>> MATERIALS = new ArrayList<>(List.of(
            TextureMaterial.class, CustomShaderMaterial.class, BlockTextureSheetMaterial.class
    ));

    static IMaterial deserializeWrapper(CompoundTag tag) {
        var type = tag.m_128461_("_type");
        for (var clazz : MATERIALS) {
            if (clazz.getSimpleName().equals(type)) {
                try {
                    IMaterial shape = clazz.getConstructor().newInstance();
                    shape.deserializeNBT(tag);
                    return shape;
                } catch (Throwable ignored) {}
            }
        }
        return null;
    }

    void begin(boolean isInstancing);

    void end(boolean isInstancing);

    IGuiTexture preview();

    @Override
    default CompoundTag serializeNBT() {
        var tag = new CompoundTag();
        tag.m_128359_("_type", getClass().getSimpleName());
        return serializeNBT(tag);
    }

    CompoundTag serializeNBT(CompoundTag tag);

    default IMaterial copy() {
        return deserializeWrapper(serializeNBT());
    }
}
