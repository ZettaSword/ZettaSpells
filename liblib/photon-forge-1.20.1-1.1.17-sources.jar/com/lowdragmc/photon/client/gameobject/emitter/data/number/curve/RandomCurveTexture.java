package com.lowdragmc.photon.client.gameobject.emitter.data.number.curve;

import com.lowdragmc.lowdraglib.gui.editor.ColorPattern;
import com.lowdragmc.lowdraglib.gui.texture.TransformTexture;
import com.lowdragmc.lowdraglib.gui.util.DrawerHelper;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.*;
import lombok.Setter;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.world.phys.Vec2;
import org.joml.Matrix4f;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Function;

/**
 * @author KilaBash
 * @date 2023/5/30
 * @implNote RandomCurveTexture
 */
public class RandomCurveTexture extends TransformTexture {
    private final ECBCurves curves0, curves1;

    private int color = ColorPattern.T_GREEN.color;

    @Setter
    private float width = 0.5f;

    public RandomCurveTexture(ECBCurves curves0, ECBCurves curves1) {
        this.curves0 = curves0;
        this.curves1 = curves1;
    }

    @Override
    public RandomCurveTexture setColor(int color) {
        this.color = color;
        return this;
    }

    @Override
    @Environment(EnvType.CLIENT)
    protected void drawInternal(GuiGraphics graphics, int mouseX, int mouseY, float x, float y, int width, int height) {
        // render area
        BufferBuilder bufferBuilder = Tesselator.m_85913_().m_85915_();
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.setShader(GameRenderer::m_172811_);
        bufferBuilder.m_166779_(VertexFormat.Mode.QUADS, DefaultVertexFormat.f_85815_);
        var matrix = graphics.m_280168_().m_85850_().m_252922_();
        Function<Vec2, Vec2> getPointPosition = coord -> new Vec2(x + width * coord.f_82470_, y + height * (1 - coord.f_82471_));
        for (int i = 0; i < width; i++) {
            float x0 = i * 1f / width;
            float x1 = (i + 1) * 1f / width;

            var p0 = getPointPosition.apply(new Vec2(x0, curves0.getCurveY(x0)));
            var p1 = getPointPosition.apply(new Vec2(x1, curves0.getCurveY(x1)));
            var p2 = getPointPosition.apply(new Vec2(x1, curves1.getCurveY(x1)));
            var p3 = getPointPosition.apply(new Vec2(x0, curves1.getCurveY(x0)));

            bufferBuilder.m_252986_(matrix, p0.f_82470_, p0.f_82471_, 0.0f).m_193479_(ColorPattern.T_RED.color).m_5752_();
            bufferBuilder.m_252986_(matrix, p1.f_82470_, p1.f_82471_, 0.0f).m_193479_(ColorPattern.T_RED.color).m_5752_();
            bufferBuilder.m_252986_(matrix, p2.f_82470_, p2.f_82471_, 0.0f).m_193479_(ColorPattern.T_RED.color).m_5752_();
            bufferBuilder.m_252986_(matrix, p3.f_82470_, p3.f_82471_, 0.0f).m_193479_(ColorPattern.T_RED.color).m_5752_();

            bufferBuilder.m_252986_(matrix, p3.f_82470_, p3.f_82471_, 0.0f).m_193479_(ColorPattern.T_RED.color).m_5752_();
            bufferBuilder.m_252986_(matrix, p2.f_82470_, p2.f_82471_, 0.0f).m_193479_(ColorPattern.T_RED.color).m_5752_();
            bufferBuilder.m_252986_(matrix, p1.f_82470_, p1.f_82471_, 0.0f).m_193479_(ColorPattern.T_RED.color).m_5752_();
            bufferBuilder.m_252986_(matrix, p0.f_82470_, p0.f_82471_, 0.0f).m_193479_(ColorPattern.T_RED.color).m_5752_();
        }

        BufferUploader.m_231202_(bufferBuilder.m_231175_());
        // render lines
        renderLines(graphics, curves0, x, y, width, height);
        renderLines(graphics, curves1, x, y, width, height);
    }

    @Environment(EnvType.CLIENT)
    private void renderLines(GuiGraphics graphics, ECBCurves curves, float x, float y, int width, int height) {
        List<Vec2> points = new ArrayList<>();
        for (int i = 0; i < width; i++) {
            float coordX = i * 1f / width;
            points.add(new Vec2(coordX, curves.getCurveY(coordX)));
        }
        points.add(new Vec2(1, curves.getCurveY(1)));
        DrawerHelper.drawLines(graphics, points.stream().map(coord -> new Vec2(x + width * coord.f_82470_, y + height * (1 - coord.f_82471_))).toList(), color, color, this.width);
    }

}
