package com.lowdragmc.photon.client.gameobject.emitter.data.material;

import com.lowdragmc.lowdraglib.client.shader.management.ShaderManager;
import com.lowdragmc.lowdraglib.gui.editor.ui.Editor;
import com.lowdragmc.lowdraglib.gui.texture.IGuiTexture;
import com.lowdragmc.photon.Photon;
import com.mojang.blaze3d.pipeline.RenderTarget;
import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.*;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.ShaderInstance;
import net.minecraft.nbt.CompoundTag;
import org.joml.Matrix4f;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL30;

import javax.annotation.ParametersAreNonnullByDefault;

/**
 * @author KilaBash
 * @date 2023/6/1
 * @implNote ShaderInstanceMaterial
 */
@Environment(EnvType.CLIENT)
@ParametersAreNonnullByDefault
public abstract class ShaderInstanceMaterial implements IMaterial {

    public final ShaderTexture preview = new ShaderTexture();

    abstract public ShaderInstance getShader();

    public void setupUniform() {
    }

    @Override
    public void begin(boolean isInstancing) {
        if (Photon.isUsingShaderPack() && Editor.INSTANCE == null) {
            var lastShader = RenderSystem.getShader();

            ShaderManager.getTempTarget().m_83954_(false);
            ShaderManager.getTempTarget().m_83947_(true);
            int lastID = GL11.glGetInteger(GL30.GL_FRAMEBUFFER_BINDING);

            float imageU = 0;
            float imageV = 0;
            float imageWidth = 1;
            float imageHeight = 1;
            Tesselator tessellator = Tesselator.m_85913_();
            BufferBuilder bufferbuilder = tessellator.m_85915_();
            RenderSystem.setShader(this::getShader);
            setupUniform();

            RenderSystem.backupProjectionMatrix();
            RenderSystem.setProjectionMatrix(new Matrix4f(), VertexSorting.f_276450_);

            var stack = RenderSystem.getModelViewStack();
            stack.m_85836_();
            stack.m_166856_();
            RenderSystem.applyModelViewMatrix();

            var lightTexture = Minecraft.m_91087_().f_91063_.m_109154_();
            lightTexture.m_109896_();
            bufferbuilder.m_166779_(VertexFormat.Mode.QUADS, DefaultVertexFormat.f_85813_);



            bufferbuilder.m_5483_(-1, -1, 0).m_7421_(imageU, imageV).m_193479_(-1).m_85969_(LightTexture.f_173040_).m_5752_();
            bufferbuilder.m_5483_(1, -1, 0).m_7421_(imageU + imageWidth, imageV).m_193479_(-1).m_85969_(LightTexture.f_173040_).m_5752_();
            bufferbuilder.m_5483_(1, 1, 0).m_7421_(imageU + imageWidth, imageV + imageHeight).m_193479_(-1).m_85969_(LightTexture.f_173040_).m_5752_();
            bufferbuilder.m_5483_(-1, 1, 0).m_7421_(imageU, imageV + imageHeight).m_193479_(-1).m_85969_(LightTexture.f_173040_).m_5752_();

            tessellator.m_85914_();
            lightTexture.m_109891_();
            RenderSystem.restoreProjectionMatrix();

            stack.m_85849_();
            RenderSystem.applyModelViewMatrix();

            GlStateManager._glBindFramebuffer(36160, lastID);
            if (!ShaderManager.getInstance().hasViewPort()) {
                var mainTarget = Minecraft.m_91087_().m_91385_();
                GlStateManager._viewport(0, 0, mainTarget.f_83917_, mainTarget.f_83918_);
            }

            RenderSystem.setShaderTexture(0, ShaderManager.getTempTarget().m_83975_());
            RenderSystem.setShader(() -> lastShader);
        } else {
            RenderSystem.setShader(this::getShader);
            setupUniform();
        }
    }

    @Override
    public void end(boolean isInstancing) {
    }

    @Override
    public final CompoundTag serializeNBT() {
        return IMaterial.super.serializeNBT();
    }

    @Override
    public IGuiTexture preview() {
        return preview;
    }

    public class ShaderTexture implements IGuiTexture {

        @Override
        public void draw(GuiGraphics graphics, int mouseX, int mouseY, float x, float y, int width, int height) {
            //sub area is just different width and height
            float imageU = 0;
            float imageV = 0;
            float imageWidth = 1;
            float imageHeight = 1;
            Tesselator tessellator = Tesselator.m_85913_();
            BufferBuilder bufferbuilder = tessellator.m_85915_();
            begin(false);
            var lightTexture = Minecraft.m_91087_().f_91063_.m_109154_();
            lightTexture.m_109896_();
            var mat = graphics.m_280168_().m_85850_().m_252922_();
            bufferbuilder.m_166779_(VertexFormat.Mode.QUADS, DefaultVertexFormat.f_85813_);

            bufferbuilder.m_252986_(mat, x, y + height, 0).m_7421_(imageU, imageV + imageHeight).m_193479_(-1).m_85969_(LightTexture.f_173040_).m_5752_();
            bufferbuilder.m_252986_(mat, x + width, y + height, 0).m_7421_(imageU + imageWidth, imageV + imageHeight).m_193479_(-1).m_85969_(LightTexture.f_173040_).m_5752_();
            bufferbuilder.m_252986_(mat, x + width, y, 0).m_7421_(imageU + imageWidth, imageV).m_193479_(-1).m_85969_(LightTexture.f_173040_).m_5752_();
            bufferbuilder.m_252986_(mat, x, y, 0).m_7421_(imageU, imageV).m_193479_(-1).m_85969_(LightTexture.f_173040_).m_5752_();

            tessellator.m_85914_();
            lightTexture.m_109891_();
        }
    }

}
