package com.lowdragmc.photon.client.gameobject.emitter.data.number.color;

import F;
import com.lowdragmc.lowdraglib.gui.texture.TransformTexture;
import com.lowdragmc.lowdraglib.utils.GradientColor;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.*;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.renderer.GameRenderer;
import org.joml.Matrix4f;
import java.util.function.Function;

/**
 * @author KilaBash
 * @date 2023/5/30
 * @implNote GradientColorTexture
 */
public class GradientColorTexture  extends TransformTexture {

    public final GradientColor gradientColor;

    public GradientColorTexture(GradientColor gradientColor) {
        this.gradientColor = gradientColor;
    }

    @Override
    @Environment(EnvType.CLIENT)
    protected void drawInternal(GuiGraphics graphics, int mouseX, int mouseY, float posx, float posy, int width, int height) {
        // render color bar
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        var mat = graphics.m_280168_().m_85850_().m_252922_();
        Tesselator tesselator = Tesselator.m_85913_();
        BufferBuilder buffer = tesselator.m_85915_();
        RenderSystem.setShader(GameRenderer::m_172811_);
        buffer.m_166779_(VertexFormat.Mode.QUADS, DefaultVertexFormat.f_85815_);

        Function<Float, Float> getXPosition = coordX -> posx + width * coordX;
        var yh = height + posy;
        RandomGradientColorTexture.drawGradient(posy, width, mat, buffer, getXPosition, yh, gradientColor);

        tesselator.m_85914_();
    }
}
