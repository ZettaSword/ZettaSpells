package com.lowdragmc.photon.client.gameobject.emitter.data.number;

import com.lowdragmc.lowdraglib.gui.editor.configurator.NumberConfigurator;
import com.lowdragmc.lowdraglib.gui.widget.WidgetGroup;
import com.lowdragmc.lowdraglib.utils.Size;
import com.lowdragmc.photon.gui.editor.configurator.NumberFunctionConfigurator;
import lombok.Getter;
import lombok.Setter;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.Tag;

import java.util.function.Supplier;

/**
 * @author KilaBash
 * @date 2023/5/26
 * @implNote RandomConstant
 */
public class RandomConstant implements NumberFunction {

    @Setter
    @Getter
    private Number a, b;
    @Setter
    @Getter
    private boolean isDecimals;

    public RandomConstant() {
        a = 0;
        b = 0;
    }

    public RandomConstant(Number a, Number b, boolean isDecimals) {
        this.a = a;
        this.b = b;
        this.isDecimals = isDecimals;
    }

    public RandomConstant(NumberFunctionConfig config) {
        this(config.defaultValue(), config.defaultValue(), config.isDecimals());
    }

    @Override
    public Number get(float t, Supplier<Float> lerp) {
        float min = Math.min(a.floatValue(), b.floatValue());
        float max = Math.max(a.floatValue(), b.floatValue());
        if (min == max) return max;
        if (isDecimals) return (min + lerp.get() * (max - min));
        return (int)(min + lerp.get() * (max + 1 - min));
    }

    @Override
    public NumberFunction copy() {
        return new RandomConstant(a, b, isDecimals);
    }

    @Override
    public boolean equals(Object obj) {
        if (obj instanceof RandomConstant constant) {
            return a.equals(constant.a) && b.equals(constant.b) && isDecimals == constant.isDecimals;
        }
        return super.equals(obj);
    }

    @Override
    public void createConfigurator(WidgetGroup group, NumberFunctionConfigurator configurator) {
        var size = group.getSize();
        int width;
        WidgetGroup aGroup, bGroup;
        if (size.width > 60) {
            width = size.width / 2;
            aGroup = new WidgetGroup(0, 0, width, size.height);
            bGroup = new WidgetGroup(width, 0, width, size.height);
        } else {
            width = size.width;
            aGroup = new WidgetGroup(0, 0, width, size.height);
            bGroup = new WidgetGroup(0, 15, width, size.height);
            group.setSize(new Size(size.width, size.height + 15));
        }

        group.addWidget(aGroup);
        group.addWidget(bGroup);
        setupNumberConfigurator(configurator, width, aGroup, new NumberConfigurator("", () -> isDecimals ? a.floatValue() : a.intValue(), number -> {
            setA(number);
            configurator.updateValue(this);
        }, a, true));
        setupNumberConfigurator(configurator, width, bGroup, new NumberConfigurator("", () -> isDecimals ? b.floatValue() : b.intValue(), number -> {
            setB(number);
            configurator.updateValue(this);
        }, b, true));

    }

    private void setupNumberConfigurator(NumberFunctionConfigurator configurator, int width, WidgetGroup group, NumberConfigurator widget) {
        group.addWidget(widget
                .setRange(configurator.getConfig().min(), configurator.getConfig().max())
                .setWheel(configurator.getConfig().isDecimals() ? configurator.getConfig().wheelDur() : Math.max(1, (int) configurator.getConfig().wheelDur())));
        widget.setConfiguratorContainer(configurator.getConfiguratorContainer());
        widget.init(width);
    }

    @Override
    public CompoundTag serializeNBT() {
        var tag = new CompoundTag();
        tag.m_128379_("isDecimals", isDecimals);
        if (a instanceof Float || a instanceof Double) {
            tag.m_128350_("a", a.floatValue());
        } else {
            tag.m_128405_("a", a.intValue());
        }
        if (b instanceof Float || b instanceof Double) {
            tag.m_128350_("b", b.floatValue());
        } else {
            tag.m_128405_("b", b.intValue());
        }
        return tag;
    }

    @Override
    public void deserializeNBT(CompoundTag nbt) {
        isDecimals = nbt.m_128471_("isDecimals");
        if (nbt.m_128425_("a", Tag.f_178196_)) {
            a = nbt.m_128451_("a");
        } else {
            a = nbt.m_128457_("a");
        }
        if (nbt.m_128425_("b", Tag.f_178196_)) {
            b = nbt.m_128451_("b");
        } else {
            b = nbt.m_128457_("b");
        }
    }
}
