package com.lowdragmc.photon.client.gameobject.emitter.data.shape;

import D;
import F;
import com.lowdragmc.lowdraglib.gui.editor.annotation.Configurable;
import com.lowdragmc.lowdraglib.gui.editor.annotation.LDLRegister;
import com.lowdragmc.lowdraglib.gui.editor.annotation.NumberRange;
import com.lowdragmc.lowdraglib.utils.Vector3fHelper;
import com.lowdragmc.photon.client.gameobject.emitter.IParticleEmitter;
import com.lowdragmc.photon.client.gameobject.particle.TileParticle;
import org.joml.Vector3f;
import lombok.Getter;
import lombok.Setter;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;

/**
 * @author KilaBash
 * @date 2023/5/26
 * @implNote Sphere
 */
@LDLRegister(name = "sphere", group = "shape")
public class Sphere implements IShape {

    @Getter @Setter
    @Configurable
    @NumberRange(range = {0, 1000})
    private float radius = .5f;
    @Getter @Setter
    @Configurable
    @NumberRange(range = {0, 1})
    private float radiusThickness = 1;
    @Getter @Setter
    @Configurable
    @NumberRange(range = {0, 360}, wheel = 10)
    private float arc = 360;

    @Override
    public void nextPosVel(TileParticle particle, IParticleEmitter emitter, Vector3f position, Vector3f rotation, Vector3f scale) {
        var random = particle.getRandomSource();
        var outer = radius;
        var inner = (1 - radiusThickness) * radius;
        var origin = inner * inner * inner;
        var bound = outer * outer * outer;
        var r = outer == inner ? outer : Math.cbrt(origin + random.m_188500_() * (bound - origin));

        var theta = Math.acos(2 * random.m_188500_() - 1);
        var phi = arc * Mth.f_144832_ * random.m_188500_() / 360;

        var pos = new Vector3f((float) (r * Math.sin(theta) * Math.cos(phi)),
                (float) (r * Math.sin(theta) * Math.sin(phi)),
                (float) (r * Math.cos(theta))).mul(scale);

        particle.setLocalPos(Vector3fHelper.rotateYXY(new Vector3f(pos), rotation).add(position).add(particle.getLocalPos()), true);
        particle.setInternalVelocity(Vector3fHelper.rotateYXY(new Vector3f(pos).normalize().mul(0.05f), rotation));
    }
}
