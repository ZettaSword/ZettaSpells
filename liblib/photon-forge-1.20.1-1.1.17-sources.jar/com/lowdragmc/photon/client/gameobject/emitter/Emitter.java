package com.lowdragmc.photon.client.gameobject.emitter;

import com.lowdragmc.lowdraglib.utils.DummyWorld;
import com.lowdragmc.photon.client.gameobject.FXObject;
import lombok.Getter;
import lombok.Setter;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.renderer.LevelRenderer;
import net.minecraft.core.BlockPos;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.Level;
import org.joml.Vector3f;
import org.joml.Vector4f;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import javax.annotation.ParametersAreNonnullByDefault;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Function;

@Environment(EnvType.CLIENT)
@ParametersAreNonnullByDefault
public abstract class Emitter extends FXObject implements IParticleEmitter {
    // runtime
    @Setter
    @Getter
    protected int delay;
    @Nullable
    protected Vector3f previousPosition;
    protected Vector3f velocity = new Vector3f();
    @Getter
    protected float t;
    @Getter
    private final RandomSource threadSafeRandomSource = RandomSource.m_216337_();
    @Getter
    protected ConcurrentHashMap<Object, Float> memRandom = new ConcurrentHashMap<>();
    private final ConcurrentHashMap<BlockPos, Integer> lightCache = new ConcurrentHashMap<>();

    protected Emitter() {
        this.f_172258_ = 1;
    }

    public RandomSource getRandomSource() {
        return f_107223_;
    }

    @Override
    public final void m_5989_() {
        super.m_5989_();
        if (!m_107276_()) {
            return;
        }

        if (delay > 0) {
            delay--;
            return;
        }

        if (previousPosition != null) {
            velocity = transform.position().sub(previousPosition, new Vector3f());
        }
        previousPosition = transform.position();

        lightCache.clear();
        updateOrigin();
        update();
    }

    @Override
    public void m_107264_(double x, double y, double z) {
        //noinspection ConstantValue
        if (this.transform == null) return;
        transform.position(new Vector3f((float)x, (float)y, (float)z));
    }

    @Override
    public Vector3f getVelocity() {
        return new Vector3f(velocity);
    }

    protected void update() {
        if (this.f_107224_ >= m_107273_() && !isLooping()) {
            this.remove(false);
        }
        this.f_107224_++;
        if (m_107273_() > 0) {
            t = (this.f_107224_ % m_107273_()) * 1f / m_107273_();
        }
    }

    protected void updateOrigin() {
        this.f_107209_ = this.f_107212_;
        this.f_107210_ = this.f_107213_;
        this.f_107211_ = this.f_107214_;
        this.f_107204_ = this.f_107231_;
    }

    protected int m_6355_(float partialTick) {
        BlockPos blockPos = new BlockPos((int) this.f_107212_, (int) this.f_107213_, (int) this.f_107214_);
        var level = getLevel();
        if (level != null && (level.m_46805_(blockPos) || level instanceof DummyWorld)) {
            return LevelRenderer.m_109541_(level, blockPos);
        }
        return 0;
    }

    public float getT(float partialTicks) {
        if (this.f_107225_ > 0 ){
            return t + partialTicks / this.f_107225_;
        }
        return 0;
    }

    public float getMemRandom(Object object) {
        return getMemRandom(object, RandomSource::m_188501_);
    }

    public float getMemRandom(Object object, Function<RandomSource, Float> randomFunc) {
        var value = memRandom.get(object);
        if (value == null) return memRandom.computeIfAbsent(object, o -> randomFunc.apply(f_107223_));
        return value;
    }

    public void reset() {
        this.f_107224_ = 0;
        this.memRandom.clear();
        this.f_107220_ = false;
        this.f_107218_ = false;
        this.previousPosition = null;
        this.velocity.zero();
        this.t = 0;
    }

    @Nonnull
    public final PhotonParticleRenderType m_7556_() {
        return ParticleQueueRenderType.INSTANCE;
    }

    @Override
    public boolean m_107276_() {
        if (!f_107220_ || getParticleAmount() != 0) return true;
        return super.m_107276_();
    }

    @Override
    public int getLightColor(BlockPos pos) {
        return lightCache.computeIfAbsent(pos, p -> {
            var level = getLevel();
            if (level != null && (level.m_46805_(p) || level instanceof DummyWorld)) {
                return LevelRenderer.m_109541_(level, p);
            }
            return 0;
        });
    }

    public int getAge() {
        return f_107224_;
    }

    public void setAge(int age) {
        this.f_107224_ = age;
    }

    public boolean isLooping() {
        return false;
    }

    public void setRGBAColor(Vector4f color) {
        this.f_107227_ = color.x;
        this.f_107228_ = color.y;
        this.f_107229_ = color.z;
        this.f_107230_ = color.w;
    }

    public Vector4f getRGBAColor() {
        return new Vector4f(f_107227_, f_107228_, f_107229_, f_107230_);
    }
}
