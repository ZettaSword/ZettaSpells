package com.lowdragmc.photon.client.gameobject.emitter;

import com.lowdragmc.lowdraglib.client.shader.Shaders;
import com.lowdragmc.lowdraglib.utils.PositionedRect;
import com.lowdragmc.photon.IrisFramebufferUtils;
import com.lowdragmc.photon.Photon;
import com.lowdragmc.photon.client.gameobject.emitter.data.RendererSetting;
import com.lowdragmc.photon.client.postprocessing.BloomEffect;
import com.mojang.blaze3d.pipeline.RenderTarget;
import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.*;
import lombok.Getter;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.Minecraft;
import net.minecraft.client.particle.ParticleRenderType;
import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.client.renderer.culling.Frustum;
import net.minecraft.client.renderer.texture.TextureManager;
import net.minecraft.world.phys.AABB;
import org.joml.Vector4f;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL20;
import org.lwjgl.opengl.GL30;

import javax.annotation.Nullable;
import javax.annotation.ParametersAreNonnullByDefault;
import java.util.Comparator;
import java.util.List;

/**
 * @author KilaBash
 * @date 2023/6/5
 * @implNote IPhotonParticleRenderType
 */
@Environment(value = EnvType.CLIENT)
@ParametersAreNonnullByDefault
public abstract class PhotonParticleRenderType implements ParticleRenderType {

    @Getter
    @Nullable
    private static Frustum FRUSTUM;

    @Getter
    private static RendererSetting.Layer LAYER = RendererSetting.Layer.Translucent;

    public static boolean bloomMark = false;

    public static void renderBloom() {
        if (bloomMark) {
            // setup view port
            var lastViewport = new PositionedRect(GlStateManager.Viewport.m_157126_(), GlStateManager.Viewport.m_157127_(), GlStateManager.Viewport.m_157128_(), GlStateManager.Viewport.m_157129_());
            var input = BloomEffect.getInput();
            var output = BloomEffect.getOutput();
            var background = Minecraft.m_91087_().m_91385_();
            if (lastViewport.position.x != 0 ||
                    lastViewport.position.y != 0 ||
                    lastViewport.size.width != background.f_83915_ ||
                    lastViewport.size.height != background.f_83916_) {
                RenderSystem.viewport(0, 0, background.f_83915_, background.f_83916_);
            }

            // render bloom effect
            BloomEffect.renderBloom(
                    LAYER == RendererSetting.Layer.Opaque ? Photon.getSolidTextureID() : Photon.getTranslucentTextureID(true),
                    input.m_83975_(),
                    output);

            // clean input
            input.m_83947_(false);
            // only clear bloom color attachment
            GL20.glDrawBuffers(new int[]{GL30.GL_COLOR_ATTACHMENT1});
            GlStateManager._clearColor(0.0f, 0.0f, 0.0f, 0.0f);
            int i = GL11.GL_COLOR_BUFFER_BIT;
            GlStateManager._clear(i, Minecraft.f_91002_);
            GL20.glDrawBuffers(new int[]{GL30.GL_COLOR_ATTACHMENT0, GL30.GL_COLOR_ATTACHMENT1});
            // draw effect back to main target
            GlStateManager._colorMask(true, true, true, true);
            GlStateManager._disableDepthTest();
            GlStateManager._depthMask(false);

            GlStateManager._glBindFramebuffer(36160, LAYER == RendererSetting.Layer.Opaque ? Photon.getSolidFrameBufferID() : Photon.getTranslucentFrameBufferID());

            Shaders.getBlitShader().m_173350_("DiffuseSampler", output.m_83975_());

            Shaders.getBlitShader().m_173363_();
            GlStateManager._enableBlend();
            RenderSystem.defaultBlendFunc();

            var tesselator = Tesselator.m_85913_();
            var bufferbuilder = tesselator.m_85915_();
            bufferbuilder.m_166779_(VertexFormat.Mode.QUADS, DefaultVertexFormat.f_85814_);
            bufferbuilder.m_5483_(-1, 1, 0).m_5752_();
            bufferbuilder.m_5483_(-1, -1, 0).m_5752_();
            bufferbuilder.m_5483_(1, -1, 0).m_5752_();
            bufferbuilder.m_5483_(1, 1, 0).m_5752_();
            BufferUploader.m_231209_(bufferbuilder.m_231175_());
            Shaders.getBlitShader().m_173362_();

            GlStateManager._depthMask(true);
            GlStateManager._colorMask(true, true, true, true);
            GlStateManager._enableDepthTest();

            // restore view port
            if (lastViewport.position.x != 0 ||
                    lastViewport.position.y != 0 ||
                    lastViewport.size.width != background.f_83915_ ||
                    lastViewport.size.height != background.f_83916_) {
                RenderSystem.viewport(lastViewport.position.x, lastViewport.position.y, lastViewport.size.width, lastViewport.size.height);
            }
            bloomMark = false;
        }
    }

    public static void prepareForParticleRendering(@Nullable Frustum cullingFrustum) {
        FRUSTUM = cullingFrustum;
        LAYER = RendererSetting.Layer.Opaque;
    }

    public static void finishRender() {
        // render after opaque objects with depth test enabled, otherwise apply bloom effect in front of entities.
        if (LAYER == RendererSetting.Layer.Opaque || IrisFramebufferUtils.isRenderingGUIScreen()) {
            renderBloom();
        }

        if (LAYER == RendererSetting.Layer.Opaque) {
            LAYER = RendererSetting.Layer.Translucent;
        }
    }

    /**
     * apply bloom shader
     */
    public void beginBloom() {
        BloomEffect.bindBloomShader();
        bloomMark = true;
    }

    /**
     * reset render target and bloom color
     */
    public void endParticle() {
        BloomEffect.setBloomColor(new Vector4f(0.0f));
        var background = Minecraft.m_91087_().m_91385_();
        background.m_83947_(false);
    }

    public boolean isParallel() {
        return false;
    }

    @Override
    @Deprecated
    public final void m_6505_(BufferBuilder builder, TextureManager textureManager) {
        prepareStatus();
        begin(builder);
    }

    @Override
    @Deprecated
    public final void m_6294_(Tesselator tesselator) {
        end(tesselator.m_85915_());
        releaseStatus();
    }

    /**
     * setup opengl environment, setup shaders, uniforms.
     */
    public void prepareStatus() {

    }

    /**
     * setup buffer builder, which may be called in async.
     */
    public void begin(BufferBuilder builder) {

    }

    /**
     * upload the buffer builder. In the render thread
     */
    public void end(BufferBuilder builder) {
        BufferUploader.m_231202_(builder.m_231175_());
    }

    /**
     * restore opengl environment.
     */
    public void releaseStatus() {

    }

    /**
     * check is specific layer
     */
    public static boolean checkLayer(RendererSetting.Layer layer) {
        return LAYER == layer;
    }

    /**
     * do cull checking
     */
    public static boolean checkFrustum(AABB aabb) {
        if (FRUSTUM == null) return true;
        return FRUSTUM.m_113029_(aabb);
    }

    public static Comparator<ParticleRenderType> makeParticleRenderTypeComparator(List<ParticleRenderType> renderOrder) {
        Comparator<ParticleRenderType> vanillaComparator = Comparator.comparingInt(renderOrder::indexOf);
        return (typeOne, typeTwo) ->
        {
            boolean vanillaOne = renderOrder.contains(typeOne);
            boolean vanillaTwo = renderOrder.contains(typeTwo);

            if (vanillaOne && vanillaTwo) {
                return vanillaComparator.compare(typeOne, typeTwo);
            }
            if (!vanillaOne && !vanillaTwo) {
                return Integer.compare(System.identityHashCode(typeOne), System.identityHashCode(typeTwo));
            }
            return vanillaOne ? -1 : 1;
        };
    }

}
