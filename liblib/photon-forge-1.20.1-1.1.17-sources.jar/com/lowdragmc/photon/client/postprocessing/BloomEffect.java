package com.lowdragmc.photon.client.postprocessing;

import F;
import I;
import Z;
import com.lowdragmc.lowdraglib.utils.ColorUtils;
import com.lowdragmc.photon.IrisFramebufferUtils;
import com.lowdragmc.photon.Photon;
import com.lowdragmc.photon.client.gameobject.emitter.PhotonParticleRenderType;
import com.lowdragmc.photon.client.gameobject.emitter.data.RendererSetting;
import com.mojang.blaze3d.pipeline.RenderTarget;
import com.mojang.blaze3d.pipeline.TextureTarget;
import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.platform.TextureUtil;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.*;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.ShaderInstance;
import org.joml.Vector4f;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL20;
import org.lwjgl.opengl.GL30;

import javax.annotation.Nullable;
import java.io.IOException;
import java.lang.reflect.Field;

/**
 * @author KilaBash
 * @date 2023/6/4
 * @implNote BloomEffect
 */
@Environment(EnvType.CLIENT)
public class BloomEffect {
    private static final Minecraft MC = Minecraft.m_91087_();
    private static int LAST_WIDTH, LAST_HEIGHT;
    private static int LAST_GUI_WIDTH, LAST_GUI_HEIGHT;
    private static RenderTarget INPUT, TRANSLUCENT_INPUT, GUI_INPUT, OUTPUT;
    private static RenderTarget SWAP2A, SWAP4A, SWAP8A, SWAP2B, SWAP4B, SWAP8B;
    //Add a standalone photon particle shader and generate bloom using MRT
    private static final ShaderInstance PARTICLE = loadShader("photon:particle", DefaultVertexFormat.f_85813_);
    private static final ShaderInstance SEPARABLE_BLUR = loadShader("photon:separable_blur");
    private static final ShaderInstance UNREAL_COMPOSITE = loadShader("photon:unreal_composite");
    private static Field lastFramebuffer;

    private static ShaderInstance loadShader(String shaderName) {
        return loadShader(shaderName, DefaultVertexFormat.f_85814_);
    }

    private static ShaderInstance loadShader(String shaderName, VertexFormat format) {
        try {
            return new ShaderInstance(Minecraft.m_91087_().m_91098_(), shaderName, format);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public static RenderTarget getInput() {
        updateScreenSize();

        if (INPUT == null || IrisFramebufferUtils.getFboCachedField() != lastFramebuffer) {
            lastFramebuffer = IrisFramebufferUtils.getFboCachedField();
            int width = MC.m_91385_().f_83915_;
            int height = MC.m_91385_().f_83916_;
            resetBloomTarget(width, height);
        }

        if (!Photon.isUsingShaderPack() || IrisFramebufferUtils.isRenderingGUIScreen()) {
            return GUI_INPUT;
        }

        return PhotonParticleRenderType.checkLayer(RendererSetting.Layer.Translucent) ? TRANSLUCENT_INPUT : INPUT;
    }

    private static void resetBloomTarget(int width, int height) {
        if (INPUT != null) INPUT.m_83930_();
        INPUT = resize(null, width, height, true);
        hookDepthBuffer(INPUT, Photon.getDepthTextureID());
        //hook main target texture to attachment0
        hookColorBuffer(INPUT, Photon.getSolidTextureID(), GL30.GL_COLOR_ATTACHMENT0);
        //hook bloom target texture to attachment1
        hookColorBuffer(INPUT, INPUT.m_83975_(), GL30.GL_COLOR_ATTACHMENT1);

        GL20.glDrawBuffers(new int[]{GL30.GL_COLOR_ATTACHMENT0, GL30.GL_COLOR_ATTACHMENT1});

        if (TRANSLUCENT_INPUT != null) TRANSLUCENT_INPUT.m_83930_();
        TRANSLUCENT_INPUT = resize(null, width, height, true);
        hookDepthBuffer(TRANSLUCENT_INPUT, Photon.getDepthTextureID());
        //make translucent bloom texture same as solid target
        ((BloomTarget)TRANSLUCENT_INPUT).resetColorTexture(INPUT.m_83975_());
        hookColorBuffer(TRANSLUCENT_INPUT, Photon.getTranslucentTextureID(false), GL30.GL_COLOR_ATTACHMENT0);
        hookColorBuffer(TRANSLUCENT_INPUT, INPUT.m_83975_(), GL30.GL_COLOR_ATTACHMENT1);

        GL20.glDrawBuffers(new int[]{GL30.GL_COLOR_ATTACHMENT0, GL30.GL_COLOR_ATTACHMENT1});
    }

    /**
     * separate the world rendering target and GUI rendering target to avoid binding the wrong framebuffer
     */
    private static void resetGuiTarget(int width, int height) {
        if (GUI_INPUT != null) GUI_INPUT.m_83930_();
        GUI_INPUT = resize(null, width, height, true);
        hookDepthBuffer(GUI_INPUT, Minecraft.m_91087_().m_91385_().m_83980_());
        hookColorBuffer(GUI_INPUT, Minecraft.m_91087_().m_91385_().m_83975_(), GL30.GL_COLOR_ATTACHMENT0);
        hookColorBuffer(GUI_INPUT, GUI_INPUT.m_83975_(), GL30.GL_COLOR_ATTACHMENT1);

        GL20.glDrawBuffers(new int[]{GL30.GL_COLOR_ATTACHMENT0, GL30.GL_COLOR_ATTACHMENT1});
    }

    public static ShaderInstance getParticleShader() {
        return PARTICLE;
    }

    public static void bindBloomShader() {
        RenderSystem.setShader(() -> PARTICLE);
    }

    public static void setBloomColor(int color) {
        if (RenderSystem.getShader() != null) {
            var r = ColorUtils.red(color);
            var g = ColorUtils.green(color);
            var b = ColorUtils.blue(color);
            var a = ColorUtils.alpha(color);
            RenderSystem.getShader().m_173356_("BloomColor").m_5805_(r, g, b, a);
        }
    }

    public static void setBloomColor(Vector4f color) {
        if (RenderSystem.getShader() != null) {
            RenderSystem.getShader().m_173356_("BloomColor").m_142558_(color);
        }
    }

    public static RenderTarget getOutput() {
        OUTPUT = resize(OUTPUT, MC.m_91268_().m_85441_(), MC.m_91268_().m_85442_(), false);
        return OUTPUT;
    }

    public static void hookDepthBuffer(RenderTarget fbo, int depthBuffer) {
        //Hook DepthBuffer
        GlStateManager._glBindFramebuffer(GL30.GL_FRAMEBUFFER, fbo.f_83920_);
        if (!Photon.isStencilEnabled(fbo))
            GlStateManager._glFramebufferTexture2D(GL30.GL_FRAMEBUFFER, GL30.GL_DEPTH_ATTACHMENT, GL30.GL_TEXTURE_2D, depthBuffer, 0);
        else if (Photon.useCombinedDepthStencilAttachment()) {
            GlStateManager._glFramebufferTexture2D(GL30.GL_FRAMEBUFFER, GL30.GL_DEPTH_STENCIL_ATTACHMENT, GL30.GL_TEXTURE_2D, depthBuffer, 0);
        } else {
            GlStateManager._glFramebufferTexture2D(GL30.GL_FRAMEBUFFER, GL30.GL_DEPTH_ATTACHMENT, GL30.GL_TEXTURE_2D, depthBuffer, 0);
            GlStateManager._glFramebufferTexture2D(GL30.GL_FRAMEBUFFER, GL30.GL_STENCIL_ATTACHMENT, GL30.GL_TEXTURE_2D, depthBuffer, 0);
        }
    }

    public static void hookColorBuffer(RenderTarget fbo, int colorBuffer, int colorAttachment) {
        //Hook ColorBuffer
        GlStateManager._glBindFramebuffer(GL30.GL_FRAMEBUFFER, fbo.f_83920_);
        GlStateManager._glFramebufferTexture2D(GL30.GL_FRAMEBUFFER, colorAttachment, GL30.GL_TEXTURE_2D, colorBuffer, 0);
    }

    public static void updateScreenSize() {
        var width = MC.m_91385_().f_83915_;
        var height = MC.m_91385_().f_83916_;
        var guiWidth = MC.m_91268_().m_85445_();
        var guiHeight = MC.m_91268_().m_85446_();
        var isSizeChanged = width != LAST_WIDTH || height != LAST_HEIGHT;
        var isGuiSizeChanged = guiWidth != LAST_GUI_WIDTH || guiHeight != LAST_GUI_HEIGHT;
        if (!isSizeChanged && !isGuiSizeChanged) return;

        resetBloomTarget(width, height);
        resetGuiTarget(width, height);

        if (isSizeChanged) {
            OUTPUT = resize(OUTPUT, width, height, false);

            SWAP2A = resize(SWAP2A, width / 2, height / 2, false);
            SWAP4A = resize(SWAP4A, width / 4, height / 4, false);
            SWAP8A = resize(SWAP8A, width / 8, height / 8, false);
//        SWAP16A = resize(SWAP16A, width / 16, height / 16, false, GL11.GL_LINEAR);

            SWAP2B = resize(SWAP2B, width / 2, height / 2, false);
            SWAP4B = resize(SWAP4B, width / 4, height / 4, false);
            SWAP8B = resize(SWAP8B, width / 8, height / 8, false);
//        SWAP16B = resize(SWAP16B, width / 16, height / 16, false, GL11.GL_LINEAR);
        }

        LAST_WIDTH = width;
        LAST_HEIGHT = height;
        LAST_GUI_WIDTH = guiWidth;
        LAST_GUI_HEIGHT = guiHeight;
    }

    private static RenderTarget resize(@Nullable RenderTarget target, int width, int height, boolean useDepth) {
        if (target == null) {
            target = new BloomTarget(width, height, useDepth, Minecraft.f_91002_);
            target.m_83931_(0.0f, 0.0f, 0.0f, 0.0f);
        }
        target.m_83941_(width, height, Minecraft.f_91002_);
        target.m_83936_(GL11.GL_LINEAR);
        return target;
    }

    public static void renderBloom(int background, int input, RenderTarget output) {
        updateScreenSize();

        RenderSystem.colorMask(true, true, true, true);
        RenderSystem.disableDepthTest();
        RenderSystem.depthMask(false);
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();

        SEPARABLE_BLUR.m_173350_("DiffuseSampler", input);
        SEPARABLE_BLUR.m_173356_("BlurDir").m_7971_(1f, 0f);
        SEPARABLE_BLUR.m_173356_("Radius").m_142617_(3);
        SEPARABLE_BLUR.m_173356_("OutSize").m_7971_((float)SWAP2A.f_83915_, (float)SWAP2A.f_83916_);
        blitShader(SEPARABLE_BLUR, SWAP2A);

        SEPARABLE_BLUR.m_173350_("DiffuseSampler", SWAP2A);
        SEPARABLE_BLUR.m_173356_("BlurDir").m_7971_(0f, 1f);
        SEPARABLE_BLUR.m_173356_("Radius").m_142617_(3);
        SEPARABLE_BLUR.m_173356_("OutSize").m_7971_((float)SWAP2B.f_83915_, (float)SWAP2B.f_83916_);
        blitShader(SEPARABLE_BLUR, SWAP2B);

        SEPARABLE_BLUR.m_173350_("DiffuseSampler", SWAP2B);
        SEPARABLE_BLUR.m_173356_("BlurDir").m_7971_(1f, 0f);
        SEPARABLE_BLUR.m_173356_("Radius").m_142617_(5);
        SEPARABLE_BLUR.m_173356_("OutSize").m_7971_((float)SWAP4A.f_83915_, (float)SWAP4A.f_83916_);
        blitShader(SEPARABLE_BLUR, SWAP4A);

        SEPARABLE_BLUR.m_173350_("DiffuseSampler", SWAP4A);
        SEPARABLE_BLUR.m_173356_("BlurDir").m_7971_(0f, 1f);
        SEPARABLE_BLUR.m_173356_("Radius").m_142617_(5);
        SEPARABLE_BLUR.m_173356_("OutSize").m_7971_((float)SWAP4B.f_83915_, (float)SWAP4B.f_83916_);
        blitShader(SEPARABLE_BLUR, SWAP4B);

        SEPARABLE_BLUR.m_173350_("DiffuseSampler", SWAP4B);
        SEPARABLE_BLUR.m_173356_("BlurDir").m_7971_(1f, 0f);
        SEPARABLE_BLUR.m_173356_("Radius").m_142617_(7);
        SEPARABLE_BLUR.m_173356_("OutSize").m_7971_((float)SWAP8A.f_83915_, (float)SWAP8A.f_83916_);
        blitShader(SEPARABLE_BLUR, SWAP8A);

        SEPARABLE_BLUR.m_173350_("DiffuseSampler", SWAP8A);
        SEPARABLE_BLUR.m_173356_("BlurDir").m_7971_(0f, 1f);
        SEPARABLE_BLUR.m_173356_("Radius").m_142617_(7);
        SEPARABLE_BLUR.m_173356_("OutSize").m_7971_((float)SWAP8B.f_83915_, (float)SWAP8B.f_83916_);
        blitShader(SEPARABLE_BLUR, SWAP8B);

//        SEPARABLE_BLUR.setSampler("DiffuseSampler", SWAP8B);
//        SEPARABLE_BLUR.safeGetUniform("BlurDir").set(1f, 0f);
//        SEPARABLE_BLUR.safeGetUniform("Radius").set(9);
//        SEPARABLE_BLUR.safeGetUniform("OutSize").set((float)SWAP16A.width, (float)SWAP16A.height);
//        blitShader(SEPARABLE_BLUR, SWAP16A);
//
//        SEPARABLE_BLUR.setSampler("DiffuseSampler", SWAP16A);
//        SEPARABLE_BLUR.safeGetUniform("BlurDir").set(0f, 1f);
//        SEPARABLE_BLUR.safeGetUniform("Radius").set(9);
//        SEPARABLE_BLUR.safeGetUniform("OutSize").set((float)SWAP16B.width, (float)SWAP16B.height);
//        blitShader(SEPARABLE_BLUR, SWAP16B);

        UNREAL_COMPOSITE.m_173350_("DiffuseSampler", background);
//        UNREAL_COMPOSITE.setSampler("HighLight", input);
        UNREAL_COMPOSITE.m_173350_("BlurTexture1", SWAP2B);
        UNREAL_COMPOSITE.m_173350_("BlurTexture2", SWAP4B);
        UNREAL_COMPOSITE.m_173350_("BlurTexture3", SWAP8B);
//        UNREAL_COMPOSITE.setSampler("BlurTexture4", SWAP16B);
        UNREAL_COMPOSITE.m_173356_("BloomRadius").m_5985_(1f);
        blitShader(UNREAL_COMPOSITE, output);

        RenderSystem.depthMask(true);
        RenderSystem.colorMask(true, true, true, true);
        RenderSystem.enableDepthTest();
    }

    public static void blitShader(ShaderInstance shaderInstance, RenderTarget dist) {
        dist.m_83954_(Minecraft.f_91002_);
        dist.m_83947_(false);
        shaderInstance.m_173363_();
        Tesselator tesselator = RenderSystem.renderThreadTesselator();
        BufferBuilder bufferbuilder = tesselator.m_85915_();
        bufferbuilder.m_166779_(VertexFormat.Mode.QUADS, DefaultVertexFormat.f_85814_);
        bufferbuilder.m_5483_(-1, 1, 0).m_5752_();
        bufferbuilder.m_5483_(-1, -1, 0).m_5752_();
        bufferbuilder.m_5483_(1, -1, 0).m_5752_();
        bufferbuilder.m_5483_(1, 1, 0).m_5752_();
        BufferUploader.m_231209_(bufferbuilder.m_231175_());
        shaderInstance.m_173362_();
    }

    public static class BloomTarget extends TextureTarget {

        public BloomTarget(int width, int height, boolean useDepth, boolean clearError) {
            super(width, height, useDepth, clearError);
        }

        public void resetColorTexture(int textureId) {
            if (this.f_83923_ > -1) {
                TextureUtil.releaseTextureId(this.f_83923_);
            }

            this.f_83923_ = textureId;
        }

        public void setColorTexture(int textureId) {
            this.f_83923_ = textureId;
        }
    }
}
