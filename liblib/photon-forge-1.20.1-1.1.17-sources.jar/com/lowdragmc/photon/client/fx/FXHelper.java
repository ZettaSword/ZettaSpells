package com.lowdragmc.photon.client.fx;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.Minecraft;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.NbtIo;
import net.minecraft.nbt.Tag;
import net.minecraft.resources.ResourceLocation;

import javax.annotation.Nullable;
import javax.annotation.ParametersAreNonnullByDefault;
import I;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

/**
 * @author KilaBash
 * @date 2023/6/5
 * @implNote FXHelper
 */
@Environment(EnvType.CLIENT)
@ParametersAreNonnullByDefault
public class FXHelper {
    private final static Map<ResourceLocation, FX> CACHE = new HashMap<>();
    public static final String FX_PATH = "fx/";

    public static int clearCache() {
        var count = CACHE.size();
        CACHE.clear();
        return count;
    }

    @Nullable
    public static FX getFX(ResourceLocation fxLocation) {
        return CACHE.computeIfAbsent(fxLocation, location -> {
            ResourceLocation resourceLocation = new ResourceLocation(fxLocation.m_135827_(), FX_PATH + fxLocation.m_135815_() + ".fx");
            try (var inputStream = Minecraft.m_91087_().m_91098_().m_215595_(resourceLocation);) {
                var tag = NbtIo.m_128939_(inputStream);
                var version = tag.m_128441_("_version") ? tag.m_128451_("_version") : 0;
                var fx = new FX();
                fx.setFxLocation(fxLocation);
                fx.deserializeNBT(tag.m_128469_("fx"));
                if (version < 1) {
                    var emitters = new CompoundTag();
                    emitters.m_128365_("fxObjects", tag.m_128437_("emitters", Tag.f_178203_));
                    fx.getMainFX().deserializeNBT(emitters);
                }
                return fx;
            } catch (Exception ignored) {
                return null;
            }
        });
    }

}
