package com.lowdragmc.photon.client.fx;

import com.lowdragmc.photon.client.gameobject.IFXObject;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import org.joml.Math;
import org.joml.Quaternionf;
import org.joml.Vector3f;

import java.util.*;

/**
 * @author KilaBash
 * @date 2023/6/5
 * @implNote EntityEffect
 */
@Environment(EnvType.CLIENT)
public class EntityEffect extends FXEffect {
    public enum AutoRotate {
        NONE,
        FORWARD,
        LOOK,
        XROT,
    }
    public static Map<Entity, List<EntityEffect>> CACHE = new HashMap<>();
    public final Entity entity;
    public final AutoRotate autoRotate;

    public EntityEffect(FX fx, Level level, Entity entity, AutoRotate autoRotate) {
        super(fx, level);
        this.entity = entity;
        this.autoRotate = autoRotate;
    }

    @Override
    public void updateFXObjectTick(IFXObject fxObject) {
        if (runtime != null && fxObject == runtime.root) {
            if (!entity.m_6084_()) {
                runtime.destroy(forcedDeath);
                CACHE.computeIfAbsent(entity, p -> new ArrayList<>()).remove(this);
                if (CACHE.get(entity).isEmpty()) {
                    CACHE.remove(entity);
                }
            }
        }
    }

    @Override
    public void updateFXObjectFrame(IFXObject fxObject, float partialTicks) {
        if (runtime != null && fxObject == runtime.root) {
            var position = entity.m_20318_(partialTicks);
            runtime.root.updatePos(new Vector3f((float) (position.f_82479_ + offset.x), (float) (position.f_82480_ + offset.y), (float) (position.f_82481_ + offset.z)));
            if (autoRotate != AutoRotate.NONE) {
                switch (autoRotate) {
                    case FORWARD -> {
                        var forward = entity.m_20156_();
                        var newRotation = new Quaternionf(rotation).rotateXYZ(
                                0,
                                (float) Math.atan2(-forward.f_82481_, forward.f_82479_),
                                (float) forward.f_82480_
                        );
                        runtime.root.updateRotation(newRotation);
                    }
                    case LOOK -> {
                        var lookAngles = entity.m_20154_();
                        var newRotation = new Quaternionf(rotation).rotateXYZ(
                                0,
                                (float) Math.atan2(-lookAngles.f_82481_, lookAngles.f_82479_),
                                (float) lookAngles.f_82480_
                        );
                        runtime.root.updateRotation(newRotation);
                    }
                    case XROT -> {
                        var newRotation = new Quaternionf(rotation).rotateXYZ(
                                0,
                                Math.toRadians(-90 - entity.m_213816_()),
                                0
                        );
                        runtime.root.updateRotation(newRotation);
                    }
                }
            }
        }
    }

    @Override
    public void start() {
        if (!entity.m_6084_()) return;

        var effects = CACHE.computeIfAbsent(entity, p -> new ArrayList<>());
        if (!allowMulti) {
            var iter = effects.iterator();
            while (iter.hasNext()) {
                var effect = iter.next();
                boolean removed = false;
                if (effect.runtime != null && !effect.runtime.isAlive()) {
                    iter.remove();
                    removed = true;
                }
                if ((effect.fx.equals(fx) || Objects.equals(effect.fx.getFxLocation(), fx.getFxLocation())) && !removed) {
                    return;
                }
            }
        }
        this.runtime = fx.createRuntime();
        var root = this.runtime.getRoot();
        root.updatePos(entity.m_20318_(0).m_252839_().add(offset.x, offset.y, offset.z));
        root.updateRotation(rotation);
        root.updateScale(scale);
        this.runtime.emmit(this);
        effects.add(this);
    }
}
