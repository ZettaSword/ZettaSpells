package com.lowdragmc.photon;

import com.lowdragmc.photon.command.*;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;

import java.util.List;

/**
 * @author KilaBash
 * @date 2023/2/9
 * @implNote ServerCommands
 */
public class ServerCommands {
    public static List<LiteralArgumentBuilder<CommandSourceStack>> createServerCommands() {
        return List.of(
                Commands.m_82127_("photon")
                        .then(Commands.m_82127_("fx").requires(source -> source.m_6761_(2))
                                .then(Commands.m_82129_("location", new FxLocationArgument())
                                        .then(BlockEffectCommand.createServerCommand())
                                        .then(EntityEffectCommand.createServerCommand())
                                )
                                .then(Commands.m_82127_("remove")
                                        .then(RemoveBlockEffectCommand.createServerCommand())
                                        .then(RemoveEntityEffectCommand.createServerCommand())
                                )
                        )

        );
    }
}
