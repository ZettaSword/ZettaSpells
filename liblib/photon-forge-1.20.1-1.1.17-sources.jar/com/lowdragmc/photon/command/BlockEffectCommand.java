package com.lowdragmc.photon.command;

import com.lowdragmc.lowdraglib.networking.IHandlerContext;
import com.lowdragmc.photon.PhotonNetworking;
import com.lowdragmc.photon.client.fx.BlockEffect;
import com.lowdragmc.photon.client.fx.FX;
import com.lowdragmc.photon.client.fx.FXHelper;
import com.mojang.brigadier.Command;
import com.mojang.brigadier.arguments.BoolArgumentType;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import lombok.Setter;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.arguments.ResourceLocationArgument;
import net.minecraft.commands.arguments.coordinates.BlockPosArgument;
import net.minecraft.commands.arguments.coordinates.Vec3Argument;
import net.minecraft.core.BlockPos;
import net.minecraft.network.FriendlyByteBuf;

/**
 * @author KilaBash
 * @date 2023/6/5
 * @implNote BlockEffectCommand
 */
public class BlockEffectCommand extends EffectCommand {
    @Setter
    protected BlockPos pos;
    @Setter
    protected boolean checkState;

    public BlockEffectCommand() {
        super();
    }

    public static LiteralArgumentBuilder<CommandSourceStack> createServerCommand() {
        return Commands.m_82127_("block")
                .then(Commands.m_82129_("pos", BlockPosArgument.m_118239_())
                        .executes(c -> execute(c, false, false, false, false, false, false, false))
                        .then(Commands.m_82129_("offset", Vec3Argument.m_120847_(false))
                                .executes(c -> execute(c, true, false, false, false, false, false, false))
                                .then(Commands.m_82129_("rotation", Vec3Argument.m_120847_(false))
                                        .executes(c -> execute(c, true, true, false, false, false, false, false))
                                        .then(Commands.m_82129_("scale", Vec3Argument.m_120847_(false))
                                                .executes(c -> execute(c, true, true, true, false, false, false, false))
                                                .then(Commands.m_82129_("delay", IntegerArgumentType.integer(0))
                                                        .executes(c -> execute(c, true, true, true, true, false, false, false))
                                                        .then(Commands.m_82129_("force death", BoolArgumentType.bool())
                                                                .executes(c -> execute(c, true, true, true, true, true, false, false))
                                                                .then(Commands.m_82129_("allow multi", BoolArgumentType.bool())
                                                                        .executes(c -> execute(c, true, true, true, true, true, true, false))
                                                                        .then(Commands.m_82129_("check state", BoolArgumentType.bool())
                                                                                .executes(c -> execute(c, true, true, true, true, true, true, true)))))))
                                        .then(Commands.m_82129_("delay", IntegerArgumentType.integer(0))
                                                .executes(c -> execute(c, true, true, false, true, false, false, false))
                                                .then(Commands.m_82129_("force death", BoolArgumentType.bool())
                                                        .executes(c -> execute(c, true, true, false, true, true, false, false))
                                                        .then(Commands.m_82129_("allow multi", BoolArgumentType.bool())
                                                                .executes(c -> execute(c, true, true, false, true, true, true, false))
                                                                .then(Commands.m_82129_("check state", BoolArgumentType.bool())
                                                                        .executes(c -> execute(c, true, true, false, true, true, true, true))))))
                                )));
    }

    private static int execute(CommandContext<CommandSourceStack> context,
                               boolean offset,
                               boolean rotation,
                               boolean scale,
                               boolean delay,
                               boolean forceDeath,
                               boolean allowMulti,
                               boolean checkState) throws CommandSyntaxException {
        var command = new BlockEffectCommand();
        command.setLocation(ResourceLocationArgument.m_107011_(context, "location"));
        command.setPos(BlockPosArgument.m_118242_(context, "pos"));
        if (offset) {
            command.setOffset(Vec3Argument.m_120844_(context, "offset"));
        }
        if (rotation) {
            command.setRotation(Vec3Argument.m_120844_(context, "rotation"));
        }
        if (scale) {
            command.setScale(Vec3Argument.m_120844_(context, "scale"));
        }
        if (delay) {
            command.setDelay(IntegerArgumentType.getInteger(context, "delay"));
        }
        if (forceDeath) {
            command.setForcedDeath(BoolArgumentType.getBool(context, "force death"));
        }
        if (allowMulti) {
            command.setAllowMulti(BoolArgumentType.getBool(context, "allow multi"));
        }
        if (checkState) {
            command.setCheckState(BoolArgumentType.getBool(context, "check state"));
        }
        PhotonNetworking.NETWORK.sendToTrackingChunk(command, context.getSource().m_81372_().m_46745_(command.pos));
        return Command.SINGLE_SUCCESS;
    }

    @Override
    public void encode(FriendlyByteBuf buf) {
        super.encode(buf);
        buf.m_130064_(pos);
        buf.writeBoolean(checkState);
    }

    @Override
    public void decode(FriendlyByteBuf buf) {
        super.decode(buf);
        pos = buf.m_130135_();
        checkState = buf.readBoolean();
    }

    @Override
    @Environment(EnvType.CLIENT)
    public void execute(IHandlerContext handler) {
        if (handler.getLevel().m_46749_(pos)) {
            var fx = FXHelper.getFX(location);
            if (fx != null) {
                var effect = new BlockEffect(fx, handler.getLevel(), pos);
                effect.setOffset(offset.f_82479_, offset.f_82480_, offset.f_82481_);
                effect.setRotation(rotation.f_82479_, rotation.f_82480_, rotation.f_82481_);
                effect.setScale(scale.f_82479_, scale.f_82480_, scale.f_82481_);
                effect.setDelay(delay);
                effect.setForcedDeath(forcedDeath);
                effect.setAllowMulti(allowMulti);
                effect.setCheckState(checkState);
                effect.start();
            }
        }
    }
}
