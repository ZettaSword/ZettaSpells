package com.lowdragmc.photon.command;

import com.lowdragmc.lowdraglib.networking.IPacket;
import lombok.Setter;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.phys.Vec3;

/**
 * @author KilaBash
 * @date 2023/6/12
 * @implNote EffectCommand
 */
public abstract class EffectCommand implements IPacket {
    @Setter
    protected ResourceLocation location;
    @Setter
    protected Vec3 offset = Vec3.f_82478_;
    @Setter
    protected Vec3 rotation = Vec3.f_82478_;
    @Setter
    protected Vec3 scale = new Vec3(1, 1, 1);
    @Setter
    protected int delay;
    @Setter
    protected boolean forcedDeath;
    @Setter
    protected boolean allowMulti;

    @Override
    public void encode(FriendlyByteBuf buf) {
        buf.m_130085_(location);
        buf.writeDouble(offset.f_82479_);
        buf.writeDouble(offset.f_82480_);
        buf.writeDouble(offset.f_82481_);
        buf.writeDouble(rotation.f_82479_);
        buf.writeDouble(rotation.f_82480_);
        buf.writeDouble(rotation.f_82481_);
        buf.writeDouble(scale.f_82479_);
        buf.writeDouble(scale.f_82480_);
        buf.writeDouble(scale.f_82481_);
        buf.m_130130_(delay);
        buf.writeBoolean(forcedDeath);
        buf.writeBoolean(allowMulti);
    }

    @Override
    public void decode(FriendlyByteBuf buf) {
        location = buf.m_130281_();
        offset = new Vec3(buf.readDouble(), buf.readDouble(), buf.readDouble());
        rotation = new Vec3(buf.readDouble(), buf.readDouble(), buf.readDouble());
        scale = new Vec3(buf.readDouble(), buf.readDouble(), buf.readDouble());
        delay = buf.m_130242_();
        forcedDeath = buf.readBoolean();
        allowMulti = buf.readBoolean();
    }

}
