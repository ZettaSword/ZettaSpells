package com.lowdragmc.photon.command;

import com.lowdragmc.lowdraglib.LDLib;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.suggestion.Suggestions;
import com.mojang.brigadier.suggestion.SuggestionsBuilder;
import net.minecraft.client.Minecraft;
import net.minecraft.commands.SharedSuggestionProvider;
import net.minecraft.commands.arguments.ResourceLocationArgument;
import net.minecraft.resources.ResourceLocation;

import java.util.concurrent.CompletableFuture;

/**
 * @author KilaBash
 * @date 2023/6/12
 * @implNote FxLocationArgument
 */
public class FxLocationArgument extends ResourceLocationArgument {
    @Override
    public <S> CompletableFuture<Suggestions> listSuggestions(CommandContext<S> context, SuggestionsBuilder builder) {
        if (LDLib.isClient()) {
            return SharedSuggestionProvider.m_82957_(
                    Minecraft.m_91087_().m_91098_().m_214159_("fx", arg -> arg.m_135815_().endsWith(".fx")).keySet()
                            .stream().map(rl -> new ResourceLocation(rl.m_135827_(), rl.m_135815_().substring(3, rl.m_135815_().length() - 3))),
                    builder);
        }
        return super.listSuggestions(context, builder);
    }
}
