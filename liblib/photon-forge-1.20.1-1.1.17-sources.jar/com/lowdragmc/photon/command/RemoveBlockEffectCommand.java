package com.lowdragmc.photon.command;

import com.lowdragmc.lowdraglib.networking.IHandlerContext;
import com.lowdragmc.lowdraglib.networking.IPacket;
import com.lowdragmc.photon.PhotonNetworking;
import com.lowdragmc.photon.client.fx.BlockEffect;
import com.mojang.brigadier.Command;
import com.mojang.brigadier.arguments.BoolArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import java.util.Iterator;
import java.util.List;
import lombok.Setter;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.arguments.ResourceLocationArgument;
import net.minecraft.commands.arguments.coordinates.BlockPosArgument;
import net.minecraft.core.BlockPos;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.resources.ResourceLocation;

import javax.annotation.Nullable;

public class RemoveBlockEffectCommand implements IPacket {
    protected BlockPos pos;
    @Setter
    protected boolean force;
    @Nullable
    @Setter
    protected ResourceLocation location;

    public static LiteralArgumentBuilder<CommandSourceStack> createServerCommand() {
        return Commands.m_82127_("block")
                .then(Commands.m_82129_("pos", BlockPosArgument.m_118239_())
                        .executes(c -> execute(c, false, false))
                        .then(Commands.m_82129_("force", BoolArgumentType.bool())
                                .executes(c -> execute(c, true, false))
                                .then(Commands.m_82129_("location", ResourceLocationArgument.m_106984_())
                                        .executes(c -> execute(c, true, true)))));
    }

    private static int execute(CommandContext<CommandSourceStack> context, boolean force, boolean location) throws CommandSyntaxException {
        var command = new RemoveBlockEffectCommand();
        command.pos = BlockPosArgument.m_118242_(context, "pos");
        if (force) {
            command.setForce(BoolArgumentType.getBool(context, "force"));
        }
        if (location) {
            command.setLocation(ResourceLocationArgument.m_107011_(context, "location"));
        }
        PhotonNetworking.NETWORK.sendToTrackingChunk(command, context.getSource().m_81372_().m_46745_(command.pos));
        return Command.SINGLE_SUCCESS;
    }

    @Override
    public void encode(FriendlyByteBuf buf) {
        buf.m_130064_(pos);
        buf.writeBoolean(force);
        buf.writeBoolean(location != null);
        if (location != null) {
            buf.m_130085_(location);
        }
    }

    @Override
    public void decode(FriendlyByteBuf buf) {
        pos = buf.m_130135_();
        force = buf.readBoolean();
        if (buf.readBoolean()) {
            location = buf.m_130281_();
        }
    }

    @Override
    @Environment(EnvType.CLIENT)
    public void execute(IHandlerContext handler) {
        var effects = BlockEffect.CACHE.get(pos);
        if (effects == null) return;
        var iter = effects.iterator();
        while (iter.hasNext()) {
            var effect = iter.next();
            if (location == null || location.equals(effect.getFx().getFxLocation())) {
                iter.remove();
                var runtime = effect.getRuntime();
                if (runtime != null && runtime.isAlive()) {
                    runtime.destroy(force);
                }
            }
        }
    }
}
