package com.lowdragmc.photon.gui.editor.accessor;

import com.lowdragmc.lowdraglib.syncdata.AccessorOp;
import com.lowdragmc.lowdraglib.syncdata.accessor.CustomObjectAccessor;
import com.lowdragmc.lowdraglib.syncdata.payload.ITypedPayload;
import com.lowdragmc.lowdraglib.syncdata.payload.NbtTagPayload;
import com.lowdragmc.photon.client.gameobject.emitter.data.number.NumberFunction;
import com.lowdragmc.photon.client.gameobject.emitter.data.number.NumberFunction3;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.Tag;

/**
 * @author KilaBash
 * @date 2023/6/3
 * @implNote NumberFunction3Accessor
 */
public class NumberFunction3Accessor extends CustomObjectAccessor<NumberFunction3> {

    public NumberFunction3Accessor() {
        super(NumberFunction3.class, true);
    }

    @Override
    public ITypedPayload<?> serialize(AccessorOp op, NumberFunction3 value) {
        var tag = new CompoundTag();
        tag.m_128365_("x", NumberFunction.serializeWrapper(value.x));
        tag.m_128365_("y", NumberFunction.serializeWrapper(value.y));
        tag.m_128365_("z", NumberFunction.serializeWrapper(value.z));
        return NbtTagPayload.of(tag);
    }

    @Override
    public NumberFunction3 deserialize(AccessorOp op, ITypedPayload<?> payload) {
        if (payload instanceof NbtTagPayload nbtTagPayload && nbtTagPayload.getPayload() instanceof CompoundTag tag) {
            if (tag.m_128435_("x") == Tag.f_178198_) {
                return new NumberFunction3(tag.m_128457_("x"), tag.m_128457_("y"), tag.m_128457_("z"));
            } else {
                return new NumberFunction3(NumberFunction.deserializeWrapper(tag.m_128469_("x")),
                        NumberFunction.deserializeWrapper(tag.m_128469_("y")),
                        NumberFunction.deserializeWrapper(tag.m_128469_("z")));
            }
        }
        return null;
    }

}
